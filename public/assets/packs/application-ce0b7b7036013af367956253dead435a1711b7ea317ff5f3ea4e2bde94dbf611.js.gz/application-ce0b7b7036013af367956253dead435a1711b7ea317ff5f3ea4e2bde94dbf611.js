// app/javascript/packs/application.js

// Import the main CSS file (e.g., application.scss)
import '../stylesheets/application'

// You can also include other JavaScript files here
// import './some_other_file'
// import './checkout';

